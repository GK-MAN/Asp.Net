using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplicationAspNet.Pages
{
    public class CascadeListModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
